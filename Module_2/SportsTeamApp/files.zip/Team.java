/**
 * Team class represents a sports team with a name and roster of players.
 * Source: Liang, Y.D. (2019). Introduction to Java Programming and Data
 * Structures (12th ed.). Pearson. Case Study 10.5 adapted.
 */
public class Team {

    private String teamName = "";
    private String[] players = new String[20];
    private int playerCount = 0;

    public Team(String teamName) {
        this.teamName = teamName;
    }

    public void addPlayer(String player) {
        players[playerCount] = player;
        playerCount++;
    }

    public String[] getPlayers() {
        return players;
    }

    public int getPlayerCount() {
        return playerCount;
    }

    public String getTeamName() {
        return teamName;
    }
}
