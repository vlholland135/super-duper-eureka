import java.util.Scanner;

/**
 * TestSportsTeamApp tests the Team class by prompting the user to enter
 * team and player names, then displaying a summary of each team's roster.
 * Source: Liang, Y.D. (2019). Introduction to Java Programming and Data
 * Structures (12th ed.). Pearson. Case Study 10.5 adapted.
 */
public class TestSportsTeamApp {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String choice = "y";

        System.out.println("  Welcome to the Sports Team App");

        while (choice.equals("y")) {
            System.out.print("\n  Enter a team name: ");
            String teamName = input.nextLine();

            Team team = new Team(teamName);

            System.out.println("\n  Enter the player names:");
            System.out.print("    hint: use commas for multiple players; no spaces>: ");
            String playerInput = input.nextLine();

            String[] playerArray = playerInput.split(",");
            for (String player : playerArray) {
                team.addPlayer(player);
            }

            System.out.println("\n  --Team Summary--");
            System.out.println("  Number of players in team: " + team.getPlayerCount());
            System.out.print("  Players on team: ");
            for (int i = 0; i < team.getPlayerCount(); i++) {
                System.out.print(team.getPlayers()[i] + ",");
            }

            System.out.print("\n\n  Continue? (y/n): ");
            choice = input.nextLine();
        }

        System.out.println("\n  End of line...");
        input.close();
    }
}
